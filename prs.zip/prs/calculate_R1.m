function R1 = calculate_R1(x)

%Calculates the upper bound in the crosscorrelation without
%unsystematic errors due to third-order nonlinearities.
%
%    R1 = calculate_R1(x)
%
%    Input argument:
%    x = Input sequence
%
%    Output argument:
%    R1 = Upper bound in the crosscorrelation without unsystematic
%         errors due to third-order nonlinearities
%
%    Example:
%       x = mlbs(7);
%       R1 = calculate_R1(x)
   
a=length(x);
for k = 1:a
   if x(k) == -1
      x(k) = 0;
   end
end

x = [x;x];
store = a;

for m=0:a-1
   if (m >= store)
      break
   end

   for n=m+1:a-1
      if (n >= store)
         break
      end

      for p=n+1:a-1
         if (p >= store)
            break
         end

         for q=p+1:a-1
            if (q >= store)
               break
            end

            if mod(x([a:2*a]-m)+x([a:2*a]-n)+x([a:2*a]-p)+x([a:2*a]-q),2)==0
               if q < store 
                  store = q;

               end
            end

         end
      end
   end
end

R1 = store-1;
