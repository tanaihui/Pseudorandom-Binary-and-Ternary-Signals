function QRB_series = QRB(length)

%Calculates the quadratic residue binary series given the signal length.
%
%    QRB_series = QRB(length)
%
%    Input argument:
%    length = Length of the signal
%
%    Output argument:
%    QRB_series = Amplitude vector of the generated quadratic residue binary series
%
%    Algorithm:
%       The element r of the signal, a(r) is 1 if r is a square, mod(length).
%       a(r) is -1 otherwise.
%       a(length) is 1.
%
%    Example:
%       QRB_series = QRB(31);

QRB_series = -ones(length,1);
QRB_series(mod([1:(length-1)/2].^2,length))=1;
QRB_series(length)=1;

