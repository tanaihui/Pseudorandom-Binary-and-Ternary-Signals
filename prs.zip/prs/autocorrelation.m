function Rxx = autocorrelation(bitseries)

%Calculates the periodic autocorrelation for a given signal.
%
%    Rxx = autocorrelation(bitseries)
%
%    Input argument:
%    bitseries = Vector containing the amplitudes of the signal sequence
%
%    Output argument:
%    Rxx = Vector of the autocorrelation amplitude
%
%    Algorithm:
%       For the signal x(r) of length N with discrete Fourier transform X(k),
%       the autocorrelation is calculated from the formula
%
%                            N-1
%       autocorrelation(r) = sum X(k)X(k)' exp(2*pi*k*r/N)
%                            k=0
%
%       where X(k)' is the complex conjugate of X(k).
%
%       The resulting autocorrelation is then normalised by dividing it by N.             
%
%    Example:
%       bitseries = [1 1 -1 1 -1 1];
%       Rxx = autocorrelation(bitseries);
   
vector = (ifft(abs(fft(bitseries)).^2))/length(bitseries);
Rxx = real(vector);
