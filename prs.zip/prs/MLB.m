function MLB_series = MLB(length,polynomial)

%Calculates the MLB sequence given the signal length.
%
%    MLB_series = MLB(length)
%
%    Input argument:
%    length = Length of the signal
%    polynomial = characteristic polynomial to generate binary signal
%             
%
%    Output argument:
%    MLB_series = Amplitude vector of the generated maximum length binary sequence
%
%    Example:
%       MLB_series = MLB(127,[1 0 0 0 1 0 0 1]);

if nargin==1
    
%gives the user choice whether to specify characteristic polynomial
answer = 'a';
while (answer~='y') & (answer~='n')
   answer=input('Do you want to enter the characteristic polynomial? y/n [y]:','s');
   if isempty(answer);
      answer = 'y';
   end
end

%generates maximum length binary sequence
if answer == 'y'
   disp('Please enter the characteristic polynomial in the following format: [1 1 0 0 1 1 1]')
   poly = input('Characteristic polynomial = ');
   poly_exist = poly_check(poly);
   while poly_exist == 0
      disp('The polynomial entered is not primitive and irreducible.')
      choice=input('Do you want to reenter the characteristic polynomial? y/n [y]:','s');
      if isempty(choice);
         choice = 'y';
      end
      if choice ~= 'y'
         break
      end
      poly = input('Characteristic polynomial = ');
      poly_exist = poly_check(poly);
   end
   if poly_exist == 1
      MLB_series = poly_MLB(poly);
   else
      answer = 'n';
   end
end   

%generates default maximum length binary sequence if characteristic polynomial not given
if answer == 'n'
   disp('The default maximum length binary sequence will be generated.')
   disp('Please strike a key to continue.')
   pause
   n = round(log(length+1)/log(2));
   
   if n==2, MLB_series = poly_MLB([1 1 1]);
   elseif n==3, MLB_series = poly_MLB([1 0 1 1]);
   elseif n==4, MLB_series = poly_MLB([1 0 0 1 1]);
   elseif n==5, MLB_series = poly_MLB([1 0 0 1 0 1]);
   elseif n==6, MLB_series = poly_MLB([1 0 0 0 0 1 1]);
   elseif n==7, MLB_series = poly_MLB([1 0 0 0 0 0 1 1]);
   elseif n==8, MLB_series = poly_MLB([1 0 0 0 1 1 1 0 1]);
   elseif n==9, MLB_series = poly_MLB([1 0 0 0 0 1 0 0 0 1]);
   elseif n==10, MLB_series = poly_MLB([1 0 0 0 0 0 0 1 0 0 1]);
   elseif n==11, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 1 0 1]);
   elseif n==12, MLB_series = poly_MLB([1 0 0 0 0 0 1 0 1 0 0 1 1]);
   elseif n==13, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 1 1 0 1 1]);
   elseif n==14, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 1 0 1 0 1 1]);
   elseif n==15, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1]);
   elseif n==16, MLB_series = poly_MLB([1 0 0 0 1 0 0 0 0 0 0 0 0 1 0 1 1]);
   elseif n==17, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 1]);
   elseif n==18, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 1]);
   elseif n==19, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 1 1 1]);
   elseif n==20, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 1]);
   elseif n==21, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 1]);
   elseif n==22, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1]);
   elseif n==23, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 1]);
   elseif n==24, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 1 1 1]);
   elseif n==25, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 1]);
   else disp('Out of range')
   end

end
  
else
    if polynomial==0
        n = round(log(length+1)/log(2));
        
        if n==2, MLB_series = poly_MLB([1 1 1]);
        elseif n==3, MLB_series = poly_MLB([1 0 1 1]);
        elseif n==4, MLB_series = poly_MLB([1 0 0 1 1]);
        elseif n==5, MLB_series = poly_MLB([1 0 0 1 0 1]);
        elseif n==6, MLB_series = poly_MLB([1 0 0 0 0 1 1]);
        elseif n==7, MLB_series = poly_MLB([1 0 0 0 0 0 1 1]);
        elseif n==8, MLB_series = poly_MLB([1 0 0 0 1 1 1 0 1]);
        elseif n==9, MLB_series = poly_MLB([1 0 0 0 0 1 0 0 0 1]);
        elseif n==10, MLB_series = poly_MLB([1 0 0 0 0 0 0 1 0 0 1]);
        elseif n==11, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 1 0 1]);
        elseif n==12, MLB_series = poly_MLB([1 0 0 0 0 0 1 0 1 0 0 1 1]);
        elseif n==13, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 1 1 0 1 1]);
        elseif n==14, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 1 0 1 0 1 1]);
        elseif n==15, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1]);
        elseif n==16, MLB_series = poly_MLB([1 0 0 0 1 0 0 0 0 0 0 0 0 1 0 1 1]);
        elseif n==17, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 1]);
        elseif n==18, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 1]);
        elseif n==19, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 1 1 1]);
        elseif n==20, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 1]);
        elseif n==21, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 1]);
        elseif n==22, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1]);
        elseif n==23, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 1]);
        elseif n==24, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 1 1 1]);
        elseif n==25, MLB_series = poly_MLB([1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 1]);
        else disp('Out of range')
        end
        
    else
        MLB_series = poly_MLB(polynomial);
    end
end