function shift = third_shift(bitseries,delay1,delay2)

%Calculates the delay when a binary sequence is multiplied twice by the 
%same sequence shifted by a two different delays.
%
%    shift = third_shift(bitseries,delay1,delay2)
%
%    Input arguments:
%    bitseries = Vector containing the amplitudes of the signal sequence
%    delay1 = Delay in the second sequence with respect to the first
%    delay2 = Delay in the third sequence with respect to the first
%
%    Output argument:
%    shift = Delay in the output sequence
%
%    Example:
%       x=mlbs(7);
%       shift = third_shift(x,1,2)

N=length(bitseries);

%calculates the delayed sequences
ud1(1:delay1)=bitseries(N-delay1+1:N);
ud1(delay1+1:N)=bitseries(1:N-delay1);
ud1=ud1';
ud2(1:delay2)=bitseries(N-delay2+1:N);
ud2(delay2+1:N)=bitseries(1:N-delay2);
ud2=ud2';

%calculates the resulting shift
R=real(ifft(conj(fft(bitseries)).*fft(bitseries.*ud1.*ud2)))/N;
[i,j]=find(R>0);
shift=i-1;