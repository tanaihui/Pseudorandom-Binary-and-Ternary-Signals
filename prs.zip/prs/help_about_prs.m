function varargout = help_about_prs(varargin)
% HELP_ABOUT_PRS M-file for help_about_prs.fig
%      HELP_ABOUT_PRS, by itself, creates a new HELP_ABOUT_PRS or raises the existing
%      singleton*.
%
%      H = HELP_ABOUT_PRS returns the handle to a new HELP_ABOUT_PRS or the handle to
%      the existing singleton*.
%
%      HELP_ABOUT_PRS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in HELP_ABOUT_PRS.M with the given input arguments.
%
%      HELP_ABOUT_PRS('Property','Value',...) creates a new HELP_ABOUT_PRS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before help_about_prs_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to help_about_prs_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Copyright 2002-2003 The MathWorks, Inc.

% Edit the above text to modify the response to help help_about_prs

% Last Modified by GUIDE v2.5 02-Jun-2005 20:39:17

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @help_about_prs_OpeningFcn, ...
                   'gui_OutputFcn',  @help_about_prs_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before help_about_prs is made visible.
function help_about_prs_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to help_about_prs (see VARARGIN)

% Choose default command line output for help_about_prs
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% Make the GUI modal
set(handles.figure1,'WindowStyle','modal')

% UIWAIT makes help_about_prs wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = help_about_prs_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Ok.
function Ok_Callback(hObject, eventdata, handles)
% hObject    handle to Ok (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

delete(handles.figure1);
