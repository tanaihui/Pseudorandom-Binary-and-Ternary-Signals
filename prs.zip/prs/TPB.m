function TPB_series = TPB(length)

%Calculates the Twin Prime sequence given the signal length.
%
%    TPB_series = TPB(length)
%
%    Input argument:
%    length = Length of the signal
%
%    Output argument:
%    TPB_series = Amplitude vector of the generated Twin Prime sequence
%
%    Algorithm:
%       Twin Prime sequence exists for length, N = p*q
%       where q = p+2.
%       A quadratic residue binary sequence, {a(r)} is formed for length p.
%       A quadratic residue binary sequence, {b(r)} is formed for length q.       
%       
%       The Twin Prime sequence, {c(r)} is defined as follows:
%          c(r) = 1 for r=0 (mod(q))
%          c(r) = -1 for r=0 (mod(p)) but r~=0 (mod(q))
%          c(r) = a(r)*b(r) otherwise  
%
%    Example:
%       TPB_series = TPB(31);

%calculates the smaller root
root = -1+sqrt(1+length);

%generates the quadratic residue sequence of length equal to the smaller root
series = QRB(root);
for k = 0:root:length-root
   for n = 1:root
      QRB_root(n+k) = series(n,:);
   end
end

%calculates the larger root
root2 = root+2;

%generates the quadratic residue sequence of length equal to the larger root
series2 = QRB(root2);
for k2 = 0:root2:length-root2
   for n2 = 1:root2
      QRB_root2(n2+k2) = series2(n2,:);
   end
end

%generates the Twin Prime sequence
TPB_series=ones(length,1);
for number = 1:length
   if mod(number,root2)==0
      TPB_series(number) = 1;
   elseif (mod(number,root)==0) & (mod(number,root2)~=0)
      TPB_series(number) = -1;
   else
      TPB_series(number) = QRB_root(number) * QRB_root2(number);
   end 
end
