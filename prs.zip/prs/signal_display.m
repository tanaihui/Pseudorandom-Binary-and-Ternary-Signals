function signal_display(bitseries)

%Display a given signal on the screen as a table.
%Prints the PIPS, PIPSE and the EMINE of a signal onto the screen.
%Allows the user to save the above data into an associated file.
%Plots the signal, its discrete Fourier transform magnitude, power spectrum
%and autocorrelation.
%
%    signal_display(bitseries)
%
%    Input argument:
%    bitseries = Vector containing the amplitudes of the signal sequence
%
%    Example:
%    bitseries = [1; 1; -1; -1; 1];
%    signal_display(bitseries)

%the key determines the style of display for the discrete Fourier transform and the 
%autocorrelation sections
key = 1;

clock_pulse = 1:length(bitseries);
harmonic = 1:3*length(bitseries);
full_period = 1:length(clock_pulse)+1;
signal = [clock_pulse' bitseries];

%prints the signal onto the screen as a table
disp ('The sequence is')
disp ('  number level')
disp (signal)

%calculates PIPS
PIPS = calculate_PIPS(bitseries);
fprintf ('PIPS = %f%%\n\n', PIPS)

%calculates PIPSE
if mod(length(bitseries),2)==1
   freqv = 1:(length(bitseries)-1)/2;
else
   freqv = 1:2:length(bitseries)/2-2;
end
fprintf ('The following PIPSE and EMINE values assume uniform harmonic specifications, with the highest specified harmonic set to %d.\n',freqv(length(freqv)))
PIPSE = calculate_PIPSE(bitseries,freqv);
fprintf ('PIPSE = %f%%\n\n', PIPSE)

%calculates EMINE
if mod(length(bitseries),2)==1
   least_power = (length(bitseries)-1)/2;
   angle = pi*least_power/length(bitseries);
   for n = 1:least_power
      other_angles(n) = pi*n/length(bitseries);
      power(n) = (sin(other_angles(n))/other_angles(n))^2;
   end
   EMINE = 100*sin(angle)/angle/(sqrt(sum(power)/least_power));
else
   least_power = (length(bitseries)/2)-2;
   angle = pi*least_power/length(bitseries);
   for n = 1:2:least_power
      other_angles(n) = pi*n/length(bitseries);
      power(n) = (sin(other_angles(n))/other_angles(n))^2;
   end
   EMINE = 100*sin(angle)/angle/(sqrt(sum(power)/((least_power+1)/2)));
end
fprintf('EMINE = %f%%\n\n', EMINE)

%allows the user to save the data into a separate file called 'perturbation_output'
record  = 'a';
while (record~='y') & (record~='n')
   record=input('Do you wish to save this data? y/n [y]:','s');
   if isempty(record);
      record = 'y';
   end
end

%saves the data into 'perturbation_output'
if record == 'y'
   fid=fopen('perturbation_output','at');
   fprintf (fid,'Pseudo-random signal\n');
   fprintf (fid,'Length = %d\n', length(bitseries));
   fprintf (fid,'\n');
   for row = 1:length(bitseries)
      fprintf (fid,'%d   %d\n',clock_pulse(row),bitseries(row));
   end
   fprintf (fid,'\n');
   fprintf (fid,'PIPS = %f%%\n\n', PIPS);
   fprintf (fid,'The following PIPSE and EMINE values assume uniform harmonic specifications, with the highest specified harmonic set to %d.\n',freqv(length(freqv)));
   fprintf (fid,'PIPSE = %f%%\n\n', PIPSE);
   fprintf (fid,'EMINE = %f%%\n\n\n', EMINE);
fclose(fid);
end

%allows the user to choose whether to see any plots
answer = 'a';
while (answer~='y') & (answer~='n')
   answer=input('Do you wish to see any plots? y/n [y]:','s');
   if isempty(answer);
      answer = 'y';
   end
end

if answer == 'y'

%plots the signal levels
   sequence_plot(bitseries,full_period)
   fprintf('Press any key to continue except the Return key and some special keys.\n\n')
   pause

%plots the discrete Fourier transform magnitude
   DFT_plot(bitseries,clock_pulse,key)
   fprintf('Press any key to continue except the Return key and some special keys.\n\n')
   pause

%plots the power spectrum
   power_plot(bitseries,harmonic)
   fprintf('Press any key to continue except the Return key and some special keys.\n\n')
   pause 

%plots the autocorrelation magnitude
   autocorrelation_plot(bitseries,full_period,key)

end

