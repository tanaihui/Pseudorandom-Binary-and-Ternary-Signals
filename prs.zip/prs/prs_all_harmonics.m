function prs_all_harmonics

%Generates pseudo-random signals with all harmonics present.
%These include binary and ternary signals.
%
%Pseudo-random signals available are:
%    maximum length binary sequences
%    quadratic residue binary sequences
%    Twin Prime sequences
%    Hall sequences
%    quadratic residue ternary sequences

%allows the user the choice of signal length
repeat_length = 'y';
while repeat_length == 'y'

   length=input('Enter the length of the signal which can only be an odd integer between 3 and 49999 inclusive.\n');
   while (length<3) | (length>49999) | ((mod(length,2))~=1)
      length=input('Please enter an odd integer between 3 and 49999 inclusive.\n');
   end

%allows the user the choice of the number of signal levels
   repeat_level = 'y';
   while repeat_level == 'y'

      level = menu ('Choose one of the following:','binary signal','ternary signal');

%generates binary signals
      if level == 1

%checks if pseudo-random signals are available
          if (MLB_exist(length)==1) | (QRB_exist(length)==1) | (TPB_exist(length)==1) | (HAB_exist(length)==1)
            count = 0;

%prints on the screen the classes of pseudo-random signals available    
            disp ('Pseudo-random binary signal(s) of this length can be based on the following classes:')
  
            if MLB_exist(length) == 1
               disp ('Maximum length binary signal')
               count = count+1;
               MLB_present = 1;
            else
               MLB_present = 0;
            end
            if QRB_exist(length) == 1
               disp ('Quadratic residue binary signal')
               count = count +1;
               QRB_present = 1;
            else
               QRB_present = 0;
            end
            if TPB_exist(length) == 1
               disp ('Twin Prime signal')
               count = count+1;
               TPB_present = 1;
            else
               TPB_present = 0;
            end
            if HAB_exist(length) == 1
               disp ('Hall signal')
               count = count+1;
               HAB_present = 1;
            else
               HAB_present = 0; 
            end     
            fprintf ('\n')
 
%gives user the choice to continue or abort
            to_continue = 'a';
            while (to_continue~='y') & (to_continue~='n')
               to_continue = input('Do you want to generate the signal? y/n [y]:','s');
               if isempty(to_continue)
                  to_continue = 'y';
               end
            end

            if to_continue == 'y'
               if count>1
               repeat_class = 'y';
                  while repeat_class == 'y'
   
%allows user the choice of signal class
                     disp('Choose a signal class by entering the associated character.')
                     if MLB_present == 1
                        disp ('Maximum length binary signal : m')
                     end
                     if QRB_present == 1
                        disp ('Quadratic residue binary signal : b')
                     end
                     if TPB_present == 1
                        disp ('Twin Prime signal : t')
                     end
                     if HAB_present == 1
                        disp ('Hall signal : h')
                     end
   
                     wrong = 1;
                     while wrong == 1

                        class = input('','s');
                        fprintf ('\n')

%generates the pseudo-random signal class chosen
%generates maximum length binary signal
                        if class == 'm'
                           if MLB_present == 1
                              MLB_series = MLB(length);
                              signal_display (MLB_series)

%calculates upper bound in the crosscorrelation without
%unsystematic errors due to second and third order nonlinearities
                              R0 = calculate_R0(MLB_series);
                              R1 = calculate_R1(MLB_series);
                              fprintf('Upper bound in the crosscorrelation without unsystematic errors due to second-order nonlinearities, R0 is %d.\n\n', R0)
                              fprintf('Upper bound in the crosscorrelation without unsystematic errors due to third-order nonlinearities, R1 is %d.\n\n', R1)

%allows the user to calculate second-order terms
                              answer = 'a';
                              while (answer~='y') & (answer~='n')
                                 answer=input('Do you wish to calculate second-order terms? y/n [y]:','s');
                                 if isempty(answer);
                                    answer = 'y';
                                 end
                              end

                              if answer == 'y'
                                 fprintf('Please enter an integer between 1 and %d or enter -1 to quit.\n', length-1);
                                 delay = 1;

                                 while (delay~=-1)
                                    delay = input('Delay = ');
                                    while ((delay<1) | (delay>length-1)) & (delay~=-1)
                                       fprintf('Please enter an integer between 1 and %d or enter -1 to quit.\n', length-1);
                                       delay = input('Delay = ');
                                    end
                                    if (delay~=-1)
                                       shift = second_shift(MLB_series,delay);
                                       fprintf('The resulting shift is %d.\n\n', shift)
                                    end
                                 end
                              end

%allows the user to calculate third-order terms
                              answer = 'a';
                              while (answer~='y') & (answer~='n')
                                 answer=input('Do you wish to calculate third-order terms? y/n [y]:','s');
                                 if isempty(answer);
                                    answer = 'y';
                                 end
                              end

                              if answer == 'y'
                                 fprintf('Please enter two integers between 1 and %d or enter [-1 -1] to quit.\n', length-1);
                                 disp('The integers must be increasing in value and entered in the format [integer1 integer2].')
                                 delay1 = 1;
                                 delay2 = 2;

                                 while (delay1~=-1) | (delay2~=-1)
                                    delay = input('Delays = ');
                                    delay1 = delay(1);
                                    delay2 = delay(2);
                                    while ((delay1<1) | (delay1>length-1) | (delay2<1) | (delay2>length-1) | (delay1>delay2)) & ((delay1~=-1) | (delay2~=-1))
                                       fprintf('Please enter two integers between 1 and %d or enter [-1 -1] to quit.\n', length-1);
                                       disp('The integers must be increasing in value and entered in the format [integer1 integer2].')
                                       delay = input('Delays = ');
                                       delay1 = delay(1);
                                       delay2 = delay(2);
                                    end
                                    if (delay1~=-1) & (delay2~=-1)
                                       shift = third_shift(MLB_series,delay1,delay2);
                                       fprintf('The resulting shift is %d.\n\n', shift)
                                    end
                                 end
                              end

                              wrong = 0;
                           else
                              wrong = 1;
                           end
     
%generates quadratic residue binary signal
                        elseif class == 'b'
                           if QRB_present == 1
                              QRB_series = QRB(length);
                              signal_display (QRB_series)
                              wrong = 0;
                           else
                              wrong = 1;
                           end
 
%generates Twin Prime signal
                        elseif class == 't'
                           if TPB_present == 1
                              TPB_series = TPB(length);
                              signal_display (TPB_series)
                              wrong = 0;
                           else
                              wrong = 1;
                           end
  
%generates Hall signal
                        elseif class == 'h'
                           if HAB_present == 1
                              HAB_series = HAB(length);
                              signal_display (HAB_series)
                              wrong = 0; 
                           else
                              wrong = 1;
                           end
   
                        else
                           wrong = 1; 
                        end
  
                        if wrong == 1
                           disp ('Please only enter an available choice.')
                        end
                     end

                     repeat_class = 'a'; 
                     while (repeat_class~='y') & (repeat_class~='n')
                        repeat_class = input('Do you want to generate a pseudo-random signal based on a different class? y/n [y]:','s');
                        if isempty(repeat_class)
                           repeat_class = 'y';
                        end
                     end
                  end   

               else                       

%generates maximum length binary signal
                  if MLB_present == 1
                     MLB_series = MLB(length);
                     signal_display (MLB_series)

%calculates upper bound in the crosscorrelation without
%unsystematic errors due to second and third order nonlinearities
                     R0 = calculate_R0(MLB_series);
                     R1 = calculate_R1(MLB_series);
                     fprintf('Upper bound in the crosscorrelation without unsystematic errors due to second-order nonlinearities, R0 is %d.\n\n', R0)
                     fprintf('Upper bound in the crosscorrelation without unsystematic errors due to third-order nonlinearities, R1 is %d.\n\n', R1)

%allows the user to calculate second-order terms
                     answer = 'a';
                     while (answer~='y') & (answer~='n')
                        answer=input('Do you wish to calculate second-order terms? y/n [y]:','s');
                        if isempty(answer);
                           answer = 'y';
                        end
                     end

                     if answer == 'y'
                        fprintf('Please enter an integer between 1 and %d or enter -1 to quit.\n', length-1);
                        delay = 1;

                        while (delay~=-1)
                           delay = input('Delay = ');
                           while ((delay<1) | (delay>length-1)) & (delay~=-1)
                              fprintf('Please enter an integer between 1 and %d or enter -1 to quit.\n', length-1);
                              delay = input('Delay = ');
                           end
                           if (delay~=-1)
                              shift = second_shift(MLB_series,delay);
                              fprintf('The resulting shift is %d.\n\n', shift)
                           end
                        end
                     end

%allows the user to calculate third-order terms
                     answer = 'a';
                     while (answer~='y') & (answer~='n')
                        answer=input('Do you wish to calculate third-order terms? y/n [y]:','s');
                        if isempty(answer);
                           answer = 'y';
                        end
                     end

                     if answer == 'y'
                        fprintf('Please enter two integers between 1 and %d or enter [-1 -1] to quit.\n', length-1);
                        disp('The integers must be increasing in value and entered in the format [integer1 integer2].')
                        delay1 = 1;
                        delay2 = 2;

                        while (delay1~=-1) | (delay2~=-1)
                           delay = input('Delays = ');
                           delay1 = delay(1);
                           delay2 = delay(2);
                           while ((delay1<1) | (delay1>length-1) | (delay2<1) | (delay2>length-1) | (delay1>delay2)) & ((delay1~=-1) | (delay2~=-1))
                              fprintf('Please enter two integers between 1 and %d or enter [-1 -1] to quit.\n', length-1);
                              disp('The integers must be increasing in value and entered in the format [integer1 integer2].')
                              delay = input('Delays = ');
                              delay1 = delay(1);
                              delay2 = delay(2);
                           end
                           if (delay1~=-1) & (delay2~=-1)
                              shift = third_shift(MLB_series,delay1,delay2);
                              fprintf('The resulting shift is %d.\n\n', shift)
                           end
                        end
                     end

%generates quadratic residue binary signal
                  elseif QRB_present == 1
                     QRB_series = QRB(length);
                     signal_display (QRB_series)

%generates Twin Prime signal
                  elseif TPB_present == 1
                     TPB_series = TPB(length);
                     signal_display (TPB_series)

%generates Hall signal
                  elseif HAB_present == 1
                     HAB_series = HAB(length);
                     signal_display (HAB_series)
                  end
               end                     
            end

%no pseudo-random binary signals available
           else
            disp ('No pseudo-random binary signal is available for this length.')
            fprintf ('\n')
          end
      end

%generates ternary signals
      if level == 2
         if (QRT_exist(length)==1)
            disp ('Pseudo-random ternary signal(s) of this length can be based on the following classes:')
            disp ('Quadratic residue ternary signal')
            fprintf ('\n')
  
%gives user the choice to continue or abort
            to_continue = 'a';
            while (to_continue~='y') & (to_continue~='n')
               to_continue = input('Do you want to generate the signal? y/n [y]:','s');
               if isempty(to_continue)
                  to_continue = 'y';
               end
            end

%generates quadratic residue ternary signal
            if to_continue == 'y';     
               QRT_series = QRT(length);                        
               signal_display (QRT_series)
            end
        
%no pseudo-random ternary signals available
         else
            disp ('No pseudo-random ternary signal is available for this length.')
            fprintf ('\n')
         end
      end

      repeat_level = 'a';
      while (repeat_level~='y') & (repeat_level~='n')
         repeat_level = input('Do you want to generate a signal with a different number of levels? y/n [y]:','s');
         if isempty(repeat_level)
            repeat_level = 'y';
         end
      end
   end
 
   repeat_length = 'a';
   while (repeat_length~='y') & (repeat_length~='n')
      repeat_length = input('Do you want to generate a signal with a different length? y/n [y]:','s');
      if isempty(repeat_length)
         repeat_length = 'y';
      end
   end
end 

