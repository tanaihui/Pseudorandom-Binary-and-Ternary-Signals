function exist = QRT_exist(length)

%Checks if the quadratic residue ternary sequence exists for a particular length.
%
%    QRT_exist(length)
%
%    Input argument:
%    length = Length of the signal
%
%    Output argument:
%    exist = 1 means that the quadratic residue ternary sequence exists.
%          = 0 means that the quadratic residue ternary sequence does not exist.
%
%    Example:
%       exist = QRT_exist(46);

if (QRB_exist(length)==1) | ((mod(length-1,4)==0) & (prime(length)==1))
   exist=1;
else
   exist=0;
end
