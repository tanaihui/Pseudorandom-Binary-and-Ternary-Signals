function y = prime(length)

%Checks if a given number is a prime.
%
%    y = prime(length)
%
%    Input argument:
%    length = Number to be checked if it is a prime
%
%    Output argument:
%    y = 1 if the number is a prime
%      = 0 if it is not a prime
%
%    Example:
%       y = prime(7);  

y=1;

%integers 1 and 2 are considered primes
if (length==1) | (length==2)
   y = 1;

%the number is not a prime if it is even
elseif (mod(length,2)==0)
   y = 0;

%if the number is odd, divide it by odd numbers smaller than itself to check if 
%it is prime
else
   for number = 3:2:length-1
      if (mod(length,number)==0)
         y=0;
         break
      end
   end
end
