function sequence_plot(bitseries,full_period)

%Plots the signal levels against the clock pulses.
%This function assumes that signals with even signal length have zero mean value.
%The mean is printed only if the signal length is odd.
%
%    sequence_plot(bitseries,full_period)
%
%    Input arguments:
%    bitseries = Vector containing the amplitudes of the signal sequence
%    full_period = Vector of one period of clock pulses plus one extra clock pulse
%
%    Example:
%        bitseries = [1; 1; -1; 1; -1; 1];
%        full_period = [1:7];
%        sequence_plot(bitseries,full_period)

full_length = [bitseries; bitseries(length(bitseries))];

%plots the signal levels against the clock pulses
figure(1)
stairs(full_period-1, full_length)
axis([0  length(bitseries)  -1.2  1.2])
title ('Plot of Signal Levels')
xlabel ('Number of Clock Pulses')
ylabel ('Signal Level')
zoom on

%prints the signal mean 
if mod(length(bitseries),2)==1
   fprintf('Mean value of the signal is %f.\n\n', mean(bitseries))
end
