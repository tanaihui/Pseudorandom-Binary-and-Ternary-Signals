function QRT_series = QRT(length)

%Calculates the quadratic residue ternary series given the signal length.
%
%    QRT_series = QRT(length)
%
%    Input argument:
%    length = Length of the signal
%
%    Output argument:
%    QRT_series = Amplitude vector of the generated quadratic residue
%                 ternary series
%
%    Algorithm:
%       The element r of the signal, a(r) is 1 if r is a square, mod(length).
%       a(r) is -1 otherwise.
%       a(length) is 0.
%
%    Example:
%       QRT_series = QRT(31);

QRT_series = QRB (length);
QRT_series (length) = 0;
