function varargout = prs(varargin)
% PRS M-file for prs.fig
%      PRS, by itself, creates a new PRS or raises the existing
%      singleton*.
%
%      H = PRS returns the handle to a new PRS or the handle to
%      the existing singleton*.
%
%      PRS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PRS.M with the given input arguments.
%
%      PRS('Property','Value',...) creates a new PRS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before prs_OpeningFunction gets called.  An
%      unrecognized property signame or invalid value makes property application
%      stop.  All inputs are passed to prs_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help prs

% Last Modified by GUIDE v2.5 30-Jun-2005 17:01:47

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @prs_OpeningFcn, ...
                   'gui_OutputFcn',  @prs_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before prs is made visible.
function prs_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to prs (see VARARGIN)

% Choose default command line output for prs
handles.output = hObject;

%Initialising the arguments
handles.SignalLength=0; %Initialising signal length = 0

%Other variables
handles.Name=get(handles.SigName,'String'); %Get the string name for the signal
handles.UserResponse=[0,0,0]; %Indicating the user response for the MLB
handles.Polynomial=0; %Characteristic equation of the MLB
handles.Designed=0; %Flag to indicate signal design is complete

% Update handles structure
guidata(hObject, handles);

%Initially set enable to 'off'
set(handles.text3,'Enable','off');
set(handles.SigLen,'Enable','off');
set(handles.text4,'Enable','off');
set(handles.SigLev,'Enable','off');
set(handles.MLB,'Enable','off');
set(handles.QRB,'Enable','off');
set(handles.TPB,'Enable','off');
set(handles.HAB,'Enable','off');
set(handles.QRT,'Enable','off');
set(handles.Design,'Enable','off');
set(handles.Options,'Enable','off');


% UIWAIT makes prs wait for user response (see UIRESUME)
% uiwait(handles.PRS);


% --- Outputs from this function are returned to the command line.
function varargout = prs_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in AllHarm.
function AllHarm_Callback(hObject, eventdata, handles)
% hObject    handle to AllHarm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of AllHarm
if get(hObject,'Value')==1
    SetEnable(handles);
    set(handles.text5,'String','Signal length must be an odd integer between 3 and 49999 inclusive');
    %Reset the value to null 
    set(handles.SigLen,'String','');
    handles.SignalLength=0;
    handles.UserResponse=[0,0,0];%Reset the options outputs
    handles.Designed=0;%flag indicating signal is not designed
    guidata(hObject,handles)
else
    SetEnable(handles);
    set(handles.text3,'Enable','off');
    set(handles.SigLen,'Enable','off');
    set(handles.text4,'Enable','off');
    set(handles.SigLev,'Enable','off');
    set(handles.text5,'String','Information on signal length')
end
%Set the the other radio buttons to zero
set(handles.OddHarm,'Value',0);

% --- Executes on button press in OddHarm.
function OddHarm_Callback(hObject, eventdata, handles)
% hObject    handle to OddHarm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of OddHarm
if get(hObject,'Value')==1
    SetEnable(handles);
    set(handles.text5,'String','Signal length must be an even integer between 6 and 49998 inclusive, and not divisible by 4');
    %Reset the value to null 
    set(handles.SigLen,'String','');
    handles.SignalLength=0;
    handles.UserResponse=[0,0,0];%Reset the options outputs
    handles.Designed=0;%flag indicating signal is not designed
    guidata(hObject,handles);
else
    SetEnable(handles);
    set(handles.text3,'Enable','off');
    set(handles.SigLen,'Enable','off');
    set(handles.text4,'Enable','off');
    set(handles.SigLev,'Enable','off');
    set(handles.text5,'String','Information on signal length')
end
%Set the the other radio buttons to zero
set(handles.AllHarm,'Value',0);


function SigLen_Callback(hObject, eventdata, handles)
% hObject    handle to SigLen (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SigLen as text
%        str2double(get(hObject,'String')) returns contents of SigLen as a double

if get(handles.AllHarm,'Value')==1
    length=str2double(get(hObject,'String'));
    if (length<3) | (length>49999) | ((mod(length,2))~=1)
         errordlg('Please enter an odd integer between 3 and 49999 inclusive','Invalid Input','modal');
         SetEnable(handles);
         handles.UserResponse=[0,0,0];%Reset the options outputs
         handles.Designed=0;%flag indicating signal is not designed
         guidata(hObject,handles);
    else
       %Check if a binary or tenary signal exists for the specified length
        SigExist(length,handles);
        handles.SignalLength=length;
        guidata(hObject,handles);
    end
elseif get(handles.OddHarm,'Value')==1
    length=str2double(get(hObject,'String'));
    if (length<6) | (length>49998) | ((mod(length,2))~=0) | ((mod(length,4))==0)
         errordlg('Please enter an even integer between 6 and 49998 inclusive, and not divisible by 4','Invalid Input','modal');
         SetEnable(handles);
         handles.UserResponse=[0,0,0];%Reset the options outputs
         handles.Designed=0;%flag indicating signal is not designed
         guidata(hObject,handles);
    else
        SigExist(length/2,handles);
        handles.SignalLength=length;
        guidata(hObject,handles);
    end
end

function SetEnable(handles)
set(handles.text3,'Enable','on');
set(handles.SigLen,'Enable','on');
set(handles.text4,'Enable','on');
set(handles.SigLev,'Enable','on');
    
set(handles.MLB,'Enable','off');
set(handles.MLB,'Value',0);
set(handles.QRB,'Enable','off');
set(handles.QRB,'Value',0);
set(handles.TPB,'Enable','off');
set(handles.TPB,'Value',0);
set(handles.HAB,'Enable','off');
set(handles.HAB,'Value',0);
set(handles.QRT,'Enable','off');
set(handles.QRT,'Value',0);
set(handles.Options,'Enable','off');
set(handles.Design,'Enable','off');

% --- Executes on selection change in SigLev.
function SigLev_Callback(hObject, eventdata, handles)
% hObject    handle to SigLev (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns SigLev contents as cell array
%        contents{get(hObject,'Value')} returns selected item from SigLev
if get(hObject,'Value')==1
    %set(handles.QRT,'Enable','off');
    SetEnable(handles);
else
    SetEnable(handles);
%     set(handles.MLB,'Enable','off');
%     set(handles.QRB,'Enable','off');
%     set(handles.TPB,'Enable','off');
%     set(handles.HAB,'Enable','off');
%     set(handles.Options,'Enable','off');
%     set(handles.Design,'Enable','off');
end
if strcmp(get(handles.SigLen,'String'),'')==0
    SigLen_Callback(handles.SigLen, eventdata, handles);
end


%Function to check if a PRS signal is available to the specified length
function SigExist(length,handles);
if get(handles.SigLev,'Value')==1
    if (MLB_exist(length)==1)
        set(handles.MLB,'Enable','on');
        SignalExist(1)=1;
    else
        set(handles.MLB,'Enable','off');
        set(handles.Design,'Enable','off');
        SignalExist(1)=0;
    end
    if (QRB_exist(length)==1)
        set(handles.QRB,'Enable','on');
        SignalExist(2)=1;
    else
        set(handles.QRB,'Enable','off');
        set(handles.Design,'Enable','off');
        SignalExist(2)=0;
    end
    if(TPB_exist(length)==1)
        set(handles.TPB,'Enable','on');
        SignalExist(3)=1;
    else
        set(handles.TPB,'Enable','off');
        set(handles.Design,'Enable','off');
        SignalExist(3)=0;
    end
    if(HAB_exist(length)==1)
        set(handles.HAB,'Enable','on');
        SignalExist(4)=1;
    else
        set(handles.HAB,'Enable','off');
        set(handles.Design,'Enable','off');
        SignalExist(4)=0;
    end
else
    if QRT_exist(length)==1
        set(handles.QRT,'Enable','on');
        SignalExist(5)=1;
    else
        set(handles.QRT,'Enable','off');
        set(handles.Design,'Enable','off');
        SignalExist(5)=0;
    end
end
if sum(SignalExist)==0
     msgbox('There are no pseudo random signals for the specified length','Message','modal');
end
        


% --- Executes on button press in MLB.
function MLB_Callback(hObject, eventdata, handles)
% hObject    handle to MLB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of MLB
set(handles.QRB,'Value',0);
set(handles.TPB,'Value',0);
set(handles.HAB,'Value',0);
set(handles.QRT,'Value',0);
if get(hObject,'Value')==1
    set(handles.SigName,'String','MLB');
    set(handles.Design,'Enable','on');
    set(handles.Options,'Enable','on');
    guidata(hObject,handles);
else
    set(handles.SigName,'String','Signal');
    set(handles.Design,'Enable','off');
    set(handles.Options,'Enable','off');
    guidata(hObject,handles);
end

% --- Executes on button press in QRB.
function QRB_Callback(hObject, eventdata, handles)
% hObject    handle to QRB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of QRB
set(handles.MLB,'Value',0);
set(handles.TPB,'Value',0);
set(handles.HAB,'Value',0);
set(handles.QRT,'Value',0);
if get(hObject,'Value')==1
    set(handles.SigName,'String','QRB');
    set(handles.Design,'Enable','on');
    set(handles.Options,'Enable','off');
    guidata(hObject,handles);
else
    set(handles.SigName,'String','Signal');
    set(handles.Design,'Enable','off');
    guidata(hObject,handles);
end

% --- Executes on button press in TPB.
function TPB_Callback(hObject, eventdata, handles)
% hObject    handle to TPB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of TPB
set(handles.MLB,'Value',0);
set(handles.QRB,'Value',0);
set(handles.HAB,'Value',0);
set(handles.QRT,'Value',0);
if get(hObject,'Value')==1
    set(handles.SigName,'String','TPB');
    set(handles.Design,'Enable','on');
    set(handles.Options,'Enable','off');
    guidata(hObject,handles);
else
    set(handles.SigName,'String','Signal');
    set(handles.Design,'Enable','off');
    guidata(hObject,handles);
end

% --- Executes on button press in HAB.
function HAB_Callback(hObject, eventdata, handles)
% hObject    handle to HAB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of HAB
set(handles.MLB,'Value',0);
set(handles.QRB,'Value',0);
set(handles.TPB,'Value',0);
set(handles.QRT,'Value',0);
if get(hObject,'Value')==1
    set(handles.SigName,'String','HAB');
    set(handles.Design,'Enable','on');
    set(handles.Options,'Enable','off');
    guidata(hObject,handles);
else
    set(handles.SigName,'String','Signal');
    set(handles.Design,'Enable','off');
    guidata(hObject,handles);
end

% --- Executes on button press in QRT.
function QRT_Callback(hObject, eventdata, handles)
% hObject    handle to QRT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of QRT
set(handles.MLB,'Value',0);
set(handles.QRB,'Value',0);
set(handles.TPB,'Value',0);
set(handles.HAB,'Value',0);
if get(hObject,'Value')==1
    set(handles.SigName,'String','QRT');
    set(handles.Design,'Enable','on');
    set(handles.Options,'Enable','off');
    guidata(hObject,handles);
else
    set(handles.SigName,'String','Signal');
    set(handles.Design,'Enable','off');
    guidata(hObject,handles);
end



% --- Executes on button press in Design.
function Design_Callback(hObject, eventdata, handles)
% hObject    handle to Design (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Get the specified name for signal
handles.Name=get(handles.SigName,'String');
guidata(hObject,handles);

if get(handles.AllHarm,'Value')==1
    if get(handles.MLB,'Value')==1
        MLB_series = MLB(handles.SignalLength,handles.Polynomial);
        CalculateShift(MLB_series,handles);
        SigProp(MLB_series,handles);
        try assignin('base',handles.Name,MLB_series);catch,
        errordlg(lasterr,'Input Argument Error!','modal'),return,end;
        if handles.Polynomial==0
            msgbox('The default maximum length binary sequence has been generated','Message','modal');
        else
            msgbox('The binary sequence for the defined characteristic polynomial has been generated','Message','modal'); 
        end
        handles.Signal=MLB_series; %Save signal into handles structure;
        handles.Designed=1;%flag indicating signal is designed
        guidata(hObject,handles);
    end
    if get(handles.QRB,'Value')==1
        QRB_series = QRB(handles.SignalLength);
        SigProp(QRB_series,handles);
        try assignin('base',handles.Name,QRB_series);catch,
        errordlg(lasterr,'Input Argument Error!','modal'),return,end;
        handles.Signal=QRB_series; %Save signal into handles structure;
        handles.Designed=1;%flag indicating signal is designed
        guidata(hObject,handles);
    end
    if get(handles.TPB,'Value')==1
        TPB_series = TPB(handles.SignalLength);
        SigProp(TPB_series,handles);
        try assignin('base',handles.Name,TPB_series);catch,
        errordlg(lasterr,'Input Argument Error!','modal'),return,end;
        handles.Signal=TPB_series; %Save signal into handles structure;
        handles.Designed=1;%flag indicating signal is designed
        guidata(hObject,handles);
    end
    if get(handles.HAB,'Value')==1
        HAB_series = HAB(handles.SignalLength);
        SigProp(HAB_series,handles);
        try assignin('base',handles.Name,HAB_series);catch,
        errordlg(lasterr,'Input Argument Error!','modal'),return,end;
        handles.Signal=HAB_series; %Save signal into handles structure;
        handles.Designed=1;%flag indicating signal is designed
        guidata(hObject,handles);
    end
    if get(handles.QRT,'Value')==1
        QRT_series = QRT(handles.SignalLength);
        SigProp(QRT_series,handles);
        try assignin('base',handles.Name,QRT_series);catch,
        errordlg(lasterr,'Input Argument Error!','modal'),return,end;
        handles.Signal=QRT_series; %Save signal into handles structure;
        handles.Designed=1;%flag indicating signal is designed
        guidata(hObject,handles);
    end
elseif get(handles.OddHarm,'Value')==1
    if get(handles.MLB,'Value')==1
        MLB_series = MLB(handles.SignalLength/2,handles.Polynomial);
        CalculateShift(MLB_series,handles);
        inverse = inverse_repeat(MLB_series);
        SigProp(inverse,handles);
        try assignin('base',handles.Name,inverse);catch,
        errordlg(lasterr,'Input Argument Error!','modal'),return,end;
        if handles.Polynomial==0
            msgbox('The default maximum length binary sequence has been generated','Message','modal');
        else
            msgbox('The binary sequence for the defined characteristic polynomial has been generated','Message','modal'); 
        end
        handles.Signal=inverse; %Save signal into handles structure;
        handles.Designed=1;%flag indicating signal is designed
        guidata(hObject,handles);
    end
    if get(handles.QRB,'Value')==1
        QRB_series = QRB(handles.SignalLength/2);
        inverse = inverse_repeat(QRB_series);
        SigProp(inverse,handles);
        try assignin('base',handles.Name,inverse);catch,
        errordlg(lasterr,'Input Argument Error!','modal'),return,end;
        handles.Signal=inverse; %Save signal into handles structure;
        handles.Designed=1;%flag indicating signal is designed
        guidata(hObject,handles);
    end
    if get(handles.TPB,'Value')==1
        TPB_series = TPB(handles.SignalLength/2);
        inverse = inverse_repeat(TPB_series);
        SigProp(inverse,handles);
        try assignin('base',handles.Name,inverse);catch,
        errordlg(lasterr,'Input Argument Error!','modal'),return,end;
        handles.Signal=inverse; %Save signal into handles structure;
        handles.Designed=1;%flag indicating signal is designed
        guidata(hObject,handles);
    end
    if get(handles.HAB,'Value')==1
        HAB_series = HAB(handles.SignalLength/2);
        inverse = inverse_repeat(HAB_series);
        SigProp(inverse,handles);
        try assignin('base',handles.Name,inverse);catch,
        errordlg(lasterr,'Input Argument Error!','modal'),return,end;
        handles.Signal=inverse; %Save signal into handles structure;
        handles.Designed=1;%flag indicating signal is designed
        guidata(hObject,handles);
    end
    if get(handles.QRT,'Value')==1
        QRT_series = QRT(handles.SignalLength/2);
        inverse = inverse_repeat(QRT_series);
        SigProp(inverse,handles);
        try assignin('base',handles.Name,inverse);catch,
        errordlg(lasterr,'Input Argument Error!','modal'),return,end;
        handles.Signal=inverse; %Save signal into handles structure;
        handles.Designed=1;%flag indicating signal is designed
        guidata(hObject,handles);
    end
end

function CalculateShift(MLB_series,handles)
if handles.UserResponse(2)==1
    fprintf('\nCalculating second order shift:\nPlease enter an integer between 1 and %d or enter -1 to quit.\n', handles.SignalLength-1);
    delay = 1;
    while (delay~=-1)
       delay = input('New Delay = ');
       while ((delay<1) | (delay>handles.SignalLength-1)) & (delay~=-1)
          fprintf('Please enter an integer between 1 and %d or enter -1 to quit.\n', handles.SignalLength-1);
          delay = input('Delay = ');
       end
       if (delay~=-1)
           shift = second_shift(MLB_series,delay);
           fprintf('The resulting shift is %d.\n\n', shift)
       end
    end
end
if handles.UserResponse(3)==1
    fprintf('\nCalculating third order shift:\nPlease enter two integers between 1 and %d or enter -1 to quit.\n', handles.SignalLength-1);
    disp('The integers must be increasing in value and entered in the format [integer1 integer2].')
    delay1 = 1;
    delay2 = 2;
    delay=[delay1 delay2];
    while length(delay)==2 | (length(delay)==1 & delay~=-1)
       delay = input('New Delays = ');
       if length(delay)==2
           delay1 = delay(1);
           delay2 = delay(2);
       end
       while ((delay1<1) | (delay1>handles.SignalLength-1) | (delay2<1) | (delay2>handles.SignalLength-1)|length(delay)~=2|(delay1>delay2)) & (length(delay)==1 & delay~=-1)
          fprintf('Please enter two integers between 1 and %d or enter -1 to quit.\n', handles.SignalLength-1);
          disp('The integers must be increasing in value and entered in the format [integer1 integer2].')
          delay = input('Delays = ');
          if length(delay)==2
              delay1 = delay(1);
              delay2 = delay(2);
          end
       end
       if length(delay)==2 | (length(delay)==1 & delay~=-1)
          shift = third_shift(MLB_series,delay1,delay2);
          fprintf('The resulting shift is %d.\n\n', shift)
       end
    end
end

function SigProp(bitseries,handles)
%calculates PIPS
PIPS = calculate_PIPS(bitseries);

%calculates PIPSE
if mod(length(bitseries),2)==1
   freqv = 1:(length(bitseries)-1)/2;
else
   freqv = 1:2:length(bitseries)/2-2;
end
PIPSE = calculate_PIPSE(bitseries,freqv);

%calculates EMINE
if mod(length(bitseries),2)==1
   least_power = (length(bitseries)-1)/2;
   angle = pi*least_power/length(bitseries);
   for n = 1:least_power
      other_angles(n) = pi*n/length(bitseries);
      power(n) = (sin(other_angles(n))/other_angles(n))^2;
   end
   EMINE = 100*sin(angle)/angle/(sqrt(sum(power)/least_power));
else
   least_power = (length(bitseries)/2)-2;
   angle = pi*least_power/length(bitseries);
   for n = 1:2:least_power
      other_angles(n) = pi*n/length(bitseries);
      power(n) = (sin(other_angles(n))/other_angles(n))^2;
   end
   EMINE = 100*sin(angle)/angle/(sqrt(sum(power)/((least_power+1)/2)));
end
set(handles.PIPS,'String',num2str(PIPS));
set(handles.PIPSE,'String',num2str(PIPSE));
set(handles.EMINE,'String',num2str(EMINE));

function SigName_Callback(hObject, eventdata, handles)
% hObject    handle to SigName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SigName as text
%        str2double(get(hObject,'String')) returns contents of SigName as a double

handles.Name=get(hObject,'String');
guidata(hObject,handles);


% --- Executes on button press in Close.
function Close_Callback(hObject, eventdata, handles)
% hObject    handle to Close (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

user_response=ConfirmClose('Title','Exit PRS');
 switch lower(user_response)
 case 'no'
 %Take no action
 case 'yes'
% Prepare to close GUI application window
    delete(handles.PRS); %delete multilev window
 end

% --- Executes when user attempts to close PRS.
function PRS_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to PRS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
Close_Callback(handles.Close, eventdata, handles);

% --- Executes on button press in Options.
function Options_Callback(hObject, eventdata, handles)
% hObject    handle to Options (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

Output=Options(handles.UserResponse,get(handles.OddHarm,'Value'),handles.Polynomial);
handles.UserResponse=Output.output;
handles.Polynomial=Output.Poly;
guidata(hObject,handles);

%Change the signal length to that of the characteristic polynomial
if handles.Polynomial==0
else
    len=2^(length(handles.Polynomial)-1)-1; %2^(n-1)-1
    if get(handles.AllHarm,'value')==1
        set(handles.SigLen,'String',len); %Change the signal length
        handles.SignalLength=len;
        guidata(hObject,handles);
    elseif get(handles.OddHarm,'value')==1
        set(handles.SigLen,'String',(len*2)); %Change the signal length to twice to generate odd harmonics only
        handles.SignalLength=len*2;
        guidata(hObject,handles);
    end
end


% --------------------------------------------------------------------
function File_Callback(hObject, eventdata, handles)
% hObject    handle to File (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Exit_Callback(hObject, eventdata, handles)
% hObject    handle to Exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Close_Callback(handles.Close, eventdata, handles);

% --------------------------------------------------------------------
function Option_Callback(hObject, eventdata, handles)
% hObject    handle to Option (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if handles.Designed==1
    set(handles.SignalPlot,'Enable','on');
    set(handles.DFTPlot,'Enable','on');
    set(handles.AutoCorrPlot,'Enable','on');
    set(handles.PowerPlot,'Enable','on');
    set(handles.AllPlot,'Enable','on');
else
    set(handles.SignalPlot,'Enable','off');
    set(handles.DFTPlot,'Enable','off');
    set(handles.AutoCorrPlot,'Enable','off');
    set(handles.PowerPlot,'Enable','off');
    set(handles.AllPlot,'Enable','off');
end

% --------------------------------------------------------------------
function Help_Callback(hObject, eventdata, handles)
% hObject    handle to Help (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function SignalPlot_Callback(hObject, eventdata, handles)
% hObject    handle to SignalPlot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sequence_plot(handles.Signal,[1:handles.SignalLength+1]);

% --------------------------------------------------------------------
function DFTPlot_Callback(hObject, eventdata, handles)
% hObject    handle to DFTPlot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
DFT_plot(handles.Signal,[1:handles.SignalLength],2);

% --------------------------------------------------------------------
function AutoCorrPlot_Callback(hObject, eventdata, handles)
% hObject    handle to AutoCorrPlot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
autocorrelation_plot(handles.Signal,[1:handles.SignalLength+1],2);

% --------------------------------------------------------------------
function PowerPlot_Callback(hObject, eventdata, handles)
% hObject    handle to PowerPlot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
power_plot(handles.Signal,[1:3*handles.SignalLength],2)

% --------------------------------------------------------------------
function AllPlot_Callback(hObject, eventdata, handles)
% hObject    handle to AllPlot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sequence_plot(handles.Signal,[1:handles.SignalLength+1]);
DFT_plot(handles.Signal,[1:handles.SignalLength],1);
autocorrelation_plot(handles.Signal,[1:handles.SignalLength+1],1);
power_plot(handles.Signal,[1:3*handles.SignalLength],1)


% --------------------------------------------------------------------
function HelpAbout_Callback(hObject, eventdata, handles)
% hObject    handle to HelpAbout (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
help_about_prs();

% --------------------------------------------------------------------
function HelpIntro_Callback(hObject, eventdata, handles)
% hObject    handle to HelpIntro (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
helpwin help_introduction_prs

