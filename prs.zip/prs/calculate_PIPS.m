function PIPS = calculate_PIPS(bitseries)

%Calculates the performance index for perturbation signals, PIPS.
%
%    PIPS = calculate_PIPS(bitseries)
%    
%    Input argument:
%    bitseries = Vector containing the amplitudes of the signal sequence
%
%    Output argument:
%    PIPS = performance index for perturbation signals
%
%    Algorithm:
%                       N-1
%    PIPS = 200 * sqrt (sum (|U(k)|^2) ) / N / (umax-umin) %    
%                       k=1
%    where
%       U(k) = discrete Fourier transform of the discrete signal
%       N = signal length
%       k = harmonic number
%       umax = maximum value of the signal
%       umin = minimum value of the signal
%
%    Example:
%    bitseries = [1 -1 1 -1 -1 1 -1 1 -1 1 1 -1 -1 1 1 1 1 -1 -1 -1];
%    PIPS = calculate_PIPS(bitseries);

DFT = abs(fft(bitseries));

for k = 2:length(bitseries)
   DFT_squared(k) = DFT(k)*DFT(k);
end

PIPS = 200*sqrt(sum(DFT_squared))/length(bitseries)/(max(bitseries)-min(bitseries));

