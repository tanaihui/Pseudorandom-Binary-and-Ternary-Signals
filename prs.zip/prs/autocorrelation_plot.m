function autocorrelation_plot(bitseries,full_period,key)

%Calculates the periodic autocorrelation magnitude 
%and plots it against delay/clock-pulse interval.
%Allows the user to obtain the values of the autocorrelation magnitude
%by entering the delay/clock-pulse interval at the command window.
%
%    autocorrelation_plot(bitseries,full_period,key)
%
%    Input arguments:
%    bitseries = Vector containing the amplitudes of the signal sequence
%    full_period = Vector containing the clock pulses plus one extra pulse
%    key = Parameter specifying the harmonic content of the signal
%          This can take only the values 1 or 2.
%          1 : For use with pseudo-random signals with all harmonics present.
%              This will not activate a 'cursor' in the command window.
%              The autocorrelation magnitude will be printed on the screen.
%          2 : For use with pseudo-random signals with some harmonics suppressed
%              and other signals such as computer-generated signals.
%              Activates a 'cursor' in the command window.
%              Entering -1 for delay/clock-pulse interval will terminate this 
%              'cursor' function.
%    Example:
%       bitseries = [1; 1; -1; 1; -1; 1];
%       full_period = [1:7];
%       autocorrelation_plot(bitseries,full_period,2)

%calculates the autocorrelation magnitude
Rxx = autocorrelation(bitseries);
full_Rxx = [Rxx; Rxx(1)];

%plots graph of autocorrelation magnitude against delay/sampling interval
figure(4)
plot(full_period-1,full_Rxx)
title ('Plot of Autocorrelation Function of Signal')
axis([0  length(full_period)-1  min(Rxx)-1/length(bitseries)  max(Rxx)+1/length(bitseries)])
xlabel ('Delay/Clock-pulse Interval')
ylabel ('Autocorrelation')
zoom on

if mod(length(bitseries),2)==1 & (key==1)
%prints the autocorrelation magnitude 
   fprintf('Autocorrelation value with no delay is %f.\n', Rxx(1))
   fprintf('Autocorrelation value with %d to %d units of delay is %f.\n\n', 1, length(bitseries)-1, Rxx(2))
else
%activates 'cursor'
   disp('Enter the delay/clock-pulse interval to see its autocorrelation magnitude. If you do not want this function, enter -1.')
   delay = 0;

   while (delay~=-1)
      delay = input('Delay/clock-pulse interval = ');
      while (delay<0) & (delay~=-1) | (delay>length(bitseries)-1) | (mod(delay,1)~=0)
         fprintf('Please enter an integer between 0 and %d or enter -1 to quit.\n', length(bitseries)-1)
         delay = input('Delay/clock-pulse interval = ');
      end
      if (delay~=-1)
         fprintf('The autocorrelation magnitude is %f.\n\n', Rxx(delay+1))
      end
   end
   fprintf('\n')
end
