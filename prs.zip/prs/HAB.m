function HAB_series = HAB(length)

%Calculates the Hall series given the signal length.
%
%    HAB_series = HAB(length)
%
%    Input argument:
%    length = Length of the signal
%
%    Output argument:
%    HAB_series = Amplitude vector of the generated Hall series
%
%    Algorithm:
%       A primitive root u is first found.
%       The element r of the signal, a(r) is 1 if r=u^t(mod(length)) 
%       where t = 0, 1 or 3 (mod 6). 
%       a(r) is -1 otherwise.
%   
%    Example:
%       HAB_series = HAB(31);
        
%sets the primitive root
if length == 1051
   root = 7;
elseif (length == 1471) | (length == 16927)
   root = 6;
else
   root = 3;
end

HAB_series = -ones(length,1);

%calculates Hall series  
HAB_series(1) = 1;
HAB_series(root) = 1;
power = 3;
remainder = root^power;
position = 'a';
HAB_series(remainder) = 1;

while power<=length-1
   if position == 'a';
      added_power = 3;
      position = 'b';
   elseif position == 'b';
      added_power = 1;
      position = 'c';
   else position == 'c';
      added_power = 2;
      position = 'a';
   end

   power = power + added_power;

   if power <=length-1
      remainder = mod(remainder*(root^added_power),length);
      HAB_series(remainder) = 1;
   end
end
