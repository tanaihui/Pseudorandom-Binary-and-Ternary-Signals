function exist = HAB_exist(length)

%Checks if the Hall series exists for a particular length.
%
%    HAB_exist(length)
%
%    Input argument:
%    length = Length of the signal
%
%    Output argument:
%    exist = 1 means that the Hall series exists.
%          = 0 means that the Hall series does not exist.
%
%    Example:
%       exist = HAB_exist(46);

%Hall series cannot be of length smaller than 31
if length<31
   exist = 0;

else 
   root = sqrt((length-27)/4);

   if (prime(length)==1) & (mod(root,1)==0)
      exist = 1;
   else 
      exist = 0;
   end
end
