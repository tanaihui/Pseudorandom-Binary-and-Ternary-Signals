function exist = MLB_exist(length)

%Checks if the maximum length binary sequence exists for a particular length.
%
%    MLB_exist(length)
%
%    Input argument:
%    length = Length of the signal
%
%    Output argument:
%    exist = 1 means that the maximum length binary sequence exists.
%          = 0 means that the maximum length binary sequence does not exist.
%
%    Example:
%       exist = MLB_exist(46);

%calculates the integer above the signal length
number = length+1;

%checks if the integer above the signal length is a power of 2
while number>2
   number = number/2;
end
   
if number == 2
   exist=1;
else
   exist=0;
end
