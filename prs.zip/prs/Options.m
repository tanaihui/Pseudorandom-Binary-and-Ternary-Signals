function varargout = Options(varargin)
% OPTIONS M-Help for Options.fig
%      OPTIONS, by itself, creates a new OPTIONS or raises the existing
%      singleton*.
%
%      H = OPTIONS returns the handle to a new OPTIONS or the handle to
%      the existing singleton*.
%
%      OPTIONS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in OPTIONS.M with the given input arguments.
%
%      OPTIONS('Property','Value',...) creates a new OPTIONS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Options_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Options_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Options

% Last Modified by GUIDE v2.5 22-Jul-2005 11:59:43

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Options_OpeningFcn, ...
                   'gui_OutputFcn',  @Options_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Options is made visible.
function Options_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Options (see VARARGIN)

% Choose default command line output for Options
handles.output = varargin{1};
handles.Poly = varargin{3};

% Update handles structure
guidata(hObject, handles);

if handles.output(2)==1  
    set(handles.SecOrder,'Value',1);
end
if handles.output(3)==1
    set(handles.ThirdOrder,'Value',1);
end
if varargin{2}==0 %varargin{2} indicates if Odd Harmonics only is not selected in main gui
    set(handles.SecOrder,'Enable','on');
    set(handles.text1,'Enable','on');
else
    set(handles.SecOrder,'Enable','off');
    set(handles.text1,'Enable','off');
end
% Make the GUI modal
set(handles.figure1,'WindowStyle','modal')

% UIWAIT makes ListBox wait for user response (see UIRESUME)
 uiwait(handles.figure1);

% --- Outputs from this function are returned to the command line.
function varargout = Options_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles;
delete(handles.figure1)


% --- Executes on button press in CharPoly.
function CharPoly_Callback(hObject, eventdata, handles)
% hObject    handle to CharPoly (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of CharPoly

poly=CharPoly('Please enter a characteristic polynomial e.g 1 0 0 0 1 0 0 1 ',num2str(handles.Poly));
if poly==-1
   handles.Poly=0;
   guidata(hObject,handles);
else
   poly_exist = poly_check(poly);
   while poly_exist == 0  
       poly=CharPoly('The polynomial entered is not primitive and irreducible e.g 1 0 0 0 1 0 0 1',num2str(0))
       if poly==-1
          handles.Poly=0;
          guidata(hObject,handles);
       break
       else
          poly_exist = poly_check(poly);
       end
   end
   if poly_exist == 1
        handles.Poly = poly;
        guidata(hObject,handles);
   end
end


% --- Executes on button press in SecOrder.
function SecOrder_Callback(hObject, eventdata, handles)
% hObject    handle to SecOrder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of SecOrder
if get(hObject,'Value')==1
    handles.output(2)=1;
else
    handles.output(2)=0;
end
guidata(hObject,handles);

% --- Executes on button press in ThirdOrder.
function ThirdOrder_Callback(hObject, eventdata, handles)
% hObject    handle to ThirdOrder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of ThirdOrder
if get(hObject,'Value')==1
    handles.output(3)=1;
else
    handles.output(3)=0;
end
guidata(hObject,handles);

% --- Executes on button press in Ok.
function Ok_Callback(hObject, eventdata, handles)
% hObject    handle to Ok (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
uiresume;

% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
uiresume;


% --------------------------------------------------------------------
function Help_Callback(hObject, eventdata, handles)
% hObject    handle to Help (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function HelpCharPoly_Callback(hObject, eventdata, handles)
% hObject    handle to HelpCharPoly (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function HelpSecOrder_Callback(hObject, eventdata, handles)
% hObject    handle to HelpSecOrder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
helpwin second_shift

% --------------------------------------------------------------------
function HelpThirdOrder_Callback(hObject, eventdata, handles)
% hObject    handle to HelpThirdOrder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
 helpwin third_shift

