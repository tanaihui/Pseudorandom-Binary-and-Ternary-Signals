function varargout = CharPoly(varargin)
% CHARPOLY M-file for CharPoly.fig
%      CHARPOLY, by itself, creates a new CHARPOLY or raises the existing
%      singleton*.
%
%      H = CHARPOLY returns the handle to a new CHARPOLY or the handle to
%      the existing singleton*.
%
%      CHARPOLY('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CHARPOLY.M with the given input arguments.
%
%      CHARPOLY('Property','Value',...) creates a new CHARPOLY or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before CharPoly_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to CharPoly_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text1 to modify the response to help CharPoly

% Last Modified by GUIDE v2.5 22-Jul-2005 12:17:23

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @CharPoly_OpeningFcn, ...
                   'gui_OutputFcn',  @CharPoly_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before CharPoly is made visible.
function CharPoly_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to CharPoly (see VARARGIN)

% Choose default command line output for CharPoly
handles.output = hObject;
handles.verified=0;%Flag to indicate invalid characteristic polynomial

% Update handles structure
guidata(hObject, handles);

set(handles.text1,'String',varargin{1});
if length(varargin{2})~=1 
    set(handles.Poly,'String',varargin{2}); %Set edit box to previous valid polynomial
end; 

% Make the GUI modal
set(handles.figure1,'WindowStyle','modal')

% UIWAIT makes CharPoly wait for user response (see UIRESUME)
 uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = CharPoly_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
delete(handles.figure1);



function Poly_Callback(hObject, eventdata, handles)
% hObject    handle to Poly (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Poly as text1
%        str2double(get(hObject,'String')) returns contents of Poly as a double
handles.verified=0;
guidata(hObject,handles)
value=get(handles.Poly,'String');
value=strcat('[',value,']');
try,CharVec=evalin('base',value);,catch,
errordlg(lasterr,'Input Argument Error!','modal'),return,end;

handles.verified=verify(CharVec);

handles.output=CharVec;
%update handles structure
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function Poly_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Poly (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Ok.
function Ok_Callback(hObject, eventdata, handles)
% hObject    handle to Ok (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Poly_Callback(handles.Poly, eventdata, handles)
if handles.verified==1
   uiresume;
end

% --- Executes on button press in Cancel.
function Cancel_Callback(hObject, eventdata, handles)
% hObject    handle to Cancel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.output=-1;
guidata(hObject,handles);
uiresume;



% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
handles.output=-1;
guidata(hObject,handles);
uiresume;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Sub-functions%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function verified=verify(user_input);
verified=0;
%Checks if the the variable is of type double
if strcmp(class(user_input),'double')==0
   errordlg('Argument must be of type double','Input Argument Error!','modal');
   return
else %Else check if variable is a row vector of positive elements
   len=size(user_input);
   if (len(1)>1 || length(len)>2)
       errordlg('Argument must be a row vector','Input Argument Error!','modal');
       return
   end;
   for i=1:length(user_input)
       if user_input(i)<0
           errordlg('All elements must be positive','Input Argument Error!','modal');
           return
       end
   end 
   verified=1;
end

