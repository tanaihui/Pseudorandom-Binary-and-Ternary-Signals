% Programme to Generate Pseudo-random Perturbation Signals
% ********************************************************
%
% This programme allows the user to generate pseudo-random perturbation signals.
% These include binary and ternary signals.
% Two types of harmonic specifications are available:
%    1. All harmonics present
%    2. Even harmonics suppressed
%
% Author : Ai Hui Tan
% Date   : 1/12/1998
% Version No. 1

continue_harmonics = 'y';
while continue_harmonics =='y'

   choice = menu ('Choose a harmonic specification:','signals with no harmonics suppressed','signals with even harmonics suppressed');

   if choice == 1

%all harmonics present
      prs_all_harmonics    
   elseif choice == 2

%even harmonics suppressed
      prs_odd_harmonics
   end

   continue_harmonics = 'a';
   while (continue_harmonics~='y') & (continue_harmonics~='n')
      continue_harmonics = input('Do you want a signal with a different harmonic specification? y/n [y]:','s');
      if isempty(continue_harmonics)
         continue_harmonics = 'y';
      end
   end  
end
