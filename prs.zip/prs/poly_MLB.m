function MLB_series = poly_MLB(poly)

%Calculates the maximum length binary sequence for a given characteristic polynomial.
%
%    MLB_series = poly_MLB(poly)
%
%    Input argument:
%    poly = Characteristic polynomial of the sequence
%
%    Output argument:
%    MLB_series = Amplitude vector of the generated maximum length binary sequence
%
%    Example:
%       MLB_series = poly_MLB([1 0 0 0 1 0 0 1]);

size_poly = size(poly);

%initializes states in shift register
x(1,1) = 1;
for n = 2:size_poly(2)-1
   x(1,n) = 0;
end

bitseries(1) = -1;

%calculates maximum length binary sequence
for t = 2:2^(size_poly(2)-1)-1
   x(t,1) = mod(sum(poly(2:size_poly(2)).*x(t-1,(1:size_poly(2)-1))),2);
   for n = 2:size_poly(2)-1
      x(t,n) = x(t-1,n-1);

      if x(t,size_poly(2)-1) == 1
         bitseries(t) = 1;
      else
         bitseries(t) = -1;
      end

   end
end

MLB_series = bitseries';
