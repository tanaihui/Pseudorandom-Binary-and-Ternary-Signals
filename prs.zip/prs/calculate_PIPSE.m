function PIPSE = calculate_PIPSE(bitseries,freqv)

%Calculates the effective performance index for perturbation signals, PIPSE.
%
%    PIPSE = calculate_PIPSE(bitseries,freqv)
%
%    Input arguments:
%    bitseries = Vector containing the amplitudes of the signal sequence
%    freqv = Vector containing the non-zero harmonics
%
%    Output argument:
%    PIPSE = effective performance index for perturbation signals
%
%    Algorithm:
%                         R
%    PIPSE = 200 * sqrt (sum (|Cu'(k)|^2) ) / (umax-umin) %
%                        k=1
%    where
%       |C'u(k)| = sqrt(2)*|sin(pi*k/N)/(pi*k)*U(k)
%       R < length/2
%       umax = maximum value of the signal
%       umin = minimum value of the signal
%
%    Example:
%    bitseries = [1 -1 1 -1 -1 1 -1 1 -1 1 1 -1 -1 1 1 1 1 -1 -1 -1];
%    freqv = 1:9;
%    PIPSE = calculate_PIPSE(bitseries,freqv);

DFT = abs(fft(bitseries));

%calculates actual power
power = 0;
for k = 1:length(freqv)
   if freqv(k) == 0
      amp(k) = DFT(1)/length(bitseries);
      power(k) = amp(k)*amp(k);
   else
      angle(k) = pi*(freqv(k))/length(bitseries);
      amp(k) = abs(sin(angle(k)).*DFT(freqv(k)+1)/angle(k)/length(bitseries));
      power(k) = 2*amp(k)*amp(k);
   end
end

%calculates effective performance index 
PIPSE = 200*sqrt(sum(power))/(max(bitseries)-min(bitseries));
