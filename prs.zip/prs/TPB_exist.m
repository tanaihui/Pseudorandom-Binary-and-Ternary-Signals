function exist = TPB_exist(length)

%Checks if the Twin Prime sequence exists for a particular length.
%
%    TPB_exist(length)
%
%    Input argument:
%    length = Length of the signal
%
%    Output argument:
%    exist = 1 means that the Twin Prime sequence exists.
%          = 0 means that the Twin Prime sequence does not exist.
%
%    Example:
%       exist = TPB_exist(46);

root = -1+sqrt(1+length);

if (prime(root)==1) & (prime(root+2)==1) & (mod(root,1)==0)
   exist=1;
else
   exist=0;
end
