function poly_exist = poly_check(poly)

%Checks if a polynomial is primitive and irreducible.
%
%    poly_exist = poly_check(poly)
%
%    Input argument:
%    poly = Characteristic polynomial
%
%    Example:
%       poly_exist = poly_check([1 0 0 0 1 0 0 1])   

%generates the polynomial
series = poly_MLB(poly);

%calculates the discrete Fourier transform and checks if it is flat
X = abs(fft(series));
X(1) = [];
if min(round(10000*X)) == max(round(10000*X))
   poly_exist = 1;
else
   poly_exist = 0;
end
