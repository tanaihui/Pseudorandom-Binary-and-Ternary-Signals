function DFT_plot(bitseries,clock_pulse,key)

%Calculates the discrete Fourier Transform magnitude and plots it against harmonic number.
%Allows the user to obtain the values of the discrete Fourier transform magnitude
%by entering the harmonic number at the command window.
%
%    DFT_plot(bitseries,clock_pulse,key)
%
%    Input arguments:
%    bitseries = Vector containing the amplitudes of the signal sequence
%    clock_pulse = Vector containing the clock pulses
%    key = Parameter specifying the harmonic content of the signal
%          This can take only the values 1 or 2.
%          1 : For use with pseudo-random signals.
%              This will not activate a 'cursor' in the command window.
%              The discrete Fourier transform magnitude will be printed on the screen.
%          2 : For use with other signals such as computer-generated signals.
%              Activates a 'cursor' in the command window.
%              Entering -1 for harmonic number will terminate this 'cursor' function.
%
%    Example:
%       bitseries = [1 1 -1 1 -1 1];
%       clock_pulse = [1:6];
%       DFT_plot(bitseries,clock_pulse,2)

DFT = abs(fft(bitseries));

%plots graph of discrete Fourier transform magnitude against harmonic number
figure(2)
stem(clock_pulse-1,DFT,'-')
title ('Plot of Discrete Fourier Transform of Discrete Signal')
axis([0  length(DFT)-1  0  max(DFT)])
xlabel ('Harmonic Number')
ylabel ('Discrete Fourier Transform Magnitude')
zoom on

%prints the discrete Fourier transform magnitude if key is 1 and activates 'cursor' if key is 2.
if key == 1
   if mod(length(bitseries),2)==1
      fprintf('DFT magnitude at dc is %f.\n', DFT(1))
      fprintf('DFT magnitude at other harmonics within the period is %f.\n', DFT(2))
   else
      fprintf('DFT magnitude at odd harmonics within a period, except at harmonic %d is %f.\n', length(bitseries)/2, DFT(2))
      fprintf('DFT magnitude at harmonic %d is %f.\n', length(bitseries)/2, DFT((length(bitseries)/2)+1))
   end

else
   disp('Enter a harmonic number to see its DFT magnitude. If you do not want this function, enter -1.')
   number = 0;

   while (number~=-1)
      number = input('Harmonic number = ');
      while (number<0) & (number~=-1) | (number>length(bitseries)-1) | (mod(number,1)~=0)
         fprintf('Please enter an integer between 0 and %d or enter -1 to quit.\n',length(bitseries)-1)
         number = input('Harmonic number = ');
      end
      if (number~=-1)
         fprintf('The DFT magnitude is %f.\n\n', DFT(number+1))
      end
   end
end
