function power_plot(bitseries,harmonic)

%Calculates power and plots it against harmonic number.
%Allows the user to obtain the values of the power 
%by entering the harmonic number at the command window.
%Entering -1 for harmonic number will terminate the 'cursor' function.
%
%    power_plot(bitseries,harmonic)
%   
%    Input arguments:
%    bitseries = Vector containing the amplitudes of the signal sequence
%    harmonic = Vector of three periods of clock pulses
%
%    Example:
%       bitseries = [1; 1; -1; 1; -1; 1];
%       harmonic = [1:18];
%       power_plot(bitseries,harmonic)

DFT = abs(fft(bitseries));
three_periods = [DFT; DFT; DFT];

%calculates power
amp(1) = DFT(1)/length(bitseries);
power(1)=amp(1)^2;
for k = 2:length(three_periods)
   angle(k) = pi*(k-1)/length(bitseries);
   amp(k) = sqrt(2)/length(bitseries)*abs(sin(angle(k))*three_periods(k)/angle(k));
   power(k) = amp(k)^2;
end

%plots power against harmonic number
figure(3)
stem(harmonic-1,power,'-')
title ('Plot of Power Spectrum of Continuous Signal')
axis([0  length(power)-1  0  max(power)])
xlabel ('Harmonic Number')
ylabel ('Power Spectrum Magnitude')
zoom on

%provides 'cursor' function
disp('Enter a harmonic number to see its power spectrum magnitude. If you do not want this function, enter -1.')
value = 0;

while (value~=-1)
   value = input('Harmonic number = ');
   while (value<0) & (value~=-1) | (value>3*length(bitseries)-1) | (mod(value,1)~=0)
      fprintf('Please enter an integer between 0 and %d or enter -1 to quit.\n', 3*length(bitseries)-1);
      value = input('Harmonic number = ');
   end
   if (value~=-1)
      fprintf('The power is %f.\n\n', power(value+1))
   end
end
%end
