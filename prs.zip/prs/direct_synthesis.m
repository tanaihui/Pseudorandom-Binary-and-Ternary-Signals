% Program to Generate Direct Synthesis Perturbation Signals
% ***********************************************************
%
% This program allows the user to generate ternary perturbation 
% signals with harmonic multiples of 2 and 3 suppressed. 
% The signals have uniform magnitude in all, except two, of the 
% specified harmonics.  
%
% Author : Ai Hui Tan
% Date   : 4 June 2013
% Version No. 1
%
% The program calls the following functions from the prs package.
% HAB
% HAB_exist
% MLB
% MLB_exist
% prime
% QRB
% QRB_exist
% QRT
% QRT_exist
% TPB
% TPB_exist

disp('Welcome to the program for generating direct synthesis perturbation signals.')

continue_program = 'y';
while continue_program =='y';
   
   period=input('Please enter the preferred signal period.\n');
%period refers to the final signal period 
%basic_period refers to the period of the basic signal
   basic_period=period/6;
   if (basic_period>=5) & ((mod(basic_period,6)==1) | (mod(basic_period,6)==5))
      signal_class=[MLB_exist(basic_period) QRB_exist(basic_period) HAB_exist(basic_period) TPB_exist(basic_period) QRT_exist(basic_period)];
      if signal_class==[0 0 0 0 0];
         signal_exist=0;
      else
         signal_exist=1;
      end
   else
      signal_exist=0;
   end
   
%direct synthesis signal(s) exists for the chosen period
%class number assigned follows the following order: MLB, QRB, HAB, TPB, QRT
   if signal_exist==1
      if sum(signal_class)==1
         class_to_generate=find(signal_class==1);
      else
         disp('More than one class of signals are available as basic signals for implementing the direct synthesis approach.')
         disp('Choose a signal class by entering the associated character.')
         if signal_class(1)==1
            disp ('Maximum length binary signal : m')
         end
         if signal_class(2)==1
            disp ('Quadratic residue binary signal : b')
         end
         if signal_class(3)==1
            disp ('Hall binary signal : h')
         end
         if signal_class(4)==1
            disp ('Twin prime binary signal : t')
         end
         if signal_class(5)==1
            disp ('Quadratic residue ternary signal : q')
         end
         class = input('','s');
         fprintf ('\n')        
         if class == 'm'
            class_to_generate=1;
         elseif class == 'b'
            class_to_generate=2;
         elseif class == 'h'
            class_to_generate=3;
         elseif class == 't'
            class_to_generate=4;
         elseif class == 'q'
            class_to_generate=5;
         end
      end
   
%generates basic signal
      if class_to_generate==1
         basic_signal=MLB(basic_period);
      elseif class_to_generate==2
         basic_signal=QRB(basic_period);
      elseif class_to_generate==3
         basic_signal=HAB(basic_period);
      elseif class_to_generate==4
         basic_signal=TPB(basic_period);
      elseif class_to_generate==5
         basic_signal=QRT(basic_period);
      end
   
%generates direct synthesis signal
      a=[basic_signal;basic_signal;basic_signal;basic_signal;basic_signal;basic_signal];
      y=[1 1 0 -1 -1 0]';
      b=[];
      for k=1:basic_period
         b=[b;y];
      end
      signal=a.*b;
      U=fft(signal);
      disp('The signal has been generated.')
      fprintf('The root-mean-square value of the signal is %f.\n', sqrt(mean(signal.^2)))
      
      
      
%allows the user to save the data into a separate file called 'ds_output'
      record  = 'a';
      while (record~='y') & (record~='n')
         record=input('Do you wish to save the signal into a file? y/n [y]:','s');
         if isempty(record);
            record = 'y';
         end
      end

%saves the data into 'ds_output'
      if record == 'y'
         clock_pulse = 1:period;
         fid=fopen('ds_output','at');
         fprintf (fid,'Pseudo-random signal\n');
         fprintf (fid,'Period = %d\n', period);
         fprintf (fid,'\n');
         for row = 1:period
            fprintf (fid,'%d   %d\n',clock_pulse(row),signal(row));
         end
         fprintf (fid,'\n');
         fclose(fid);
         disp('The signal has been saved into the file "ds_output".')
      end

%allows the user to choose whether to see any plots
      answer = 'a';
      while (answer~='y') & (answer~='n')
         answer=input('Do you wish to see any plots? y/n [y]:','s');
         if isempty(answer);
            answer = 'y';
         end
      end
     
      if answer=='y'
         figure
         stem([0:length(signal)-1],signal)
         axis([0 length(signal)-1 -1 1])
         xlabel('Sample Number');ylabel('Amplitude');title('Time Domain Plot of Signal')
         figure
         stem([0:length(signal)-1],abs(U))
         axis([0 length(signal)-1 0 ceil(max(abs(U)))])
         xlabel('Harmonic Number');ylabel('DFT Magnitude');title('Frequency Domain Plot of Signal')
%calculates autocorrelation function   
         R=(real(ifft(U.*conj(U))))/length(signal);
         figure
         stem([0:length(signal)-1],R)
         axis([0 length(signal)-1 -1 1])
         xlabel('Delay');ylabel('Autocorrelation Function');title('Autocorrelation Plot of Signal')
      end
      
%direct synthesis signal does not exist for the chosen period
   elseif signal_exist==0
      disp('No direct synthesis signal exists for the preferred period.')
      m=floor(basic_period)+1;
      while signal_exist==0
         if (m>=5) & ((mod(m,6)==1) | (mod(m,6)==5))
            signal_class=[MLB_exist(m) QRB_exist(m) HAB_exist(m) TPB_exist(m) QRT_exist(m)];
            if sum(signal_class)>0
               signal_exist=1;recommended_period=m*6;
            end
         end
         m=m+1;
      end
      fprintf('The next period available is %d.\n', recommended_period)
   end
      
   continue_program = 'a';
   while (continue_program~='y') & (continue_program~='n')
      continue_program = input('Do you want to generate another signal? y/n [y]:','s');
      if isempty(continue_program)
         continue_program = 'y';
      end
   end  
end
