function prs_odd_harmonics

%Generates pseudo-random signals with only odd harmonics present.
%These include binary and ternary signals.
%
%Pseudo-random signals available are:
%    maximum length binary inverse-repeat sequences
%    quadratic residue binary inverse-repeat sequences
%    Twin Prime inverse-repeat sequences
%    Hall inverse-repeat sequences
%    quadratic residue ternary inverse-repeat sequences


%allows the user the choice of signal length
repeat_length = 'y';
while repeat_length == 'y'

   length=input('Enter the length of the signal which can only be an even integer between 6 and 49998 inclusive, and not divisible by 4.\n');
   while (length<6) | (length>49998) | ((mod(length,2))~=0) | ((mod(length,4))==0)
      if (length<6) | (length>49998)
         disp ('This is out of the available range.')
      elseif mod(length,2)~=0
         disp ('This is not an even number.')
      else
         disp ('This is divisible by 4.')
      end
      length=input('Please enter an even integer between 6 and 49998 inclusive.\n');
   end

%allows the user the choice of the number of signal levels
   repeat_level = 'y';
   while repeat_level == 'y'

      level = menu ('Choose one of the following:','binary signal','ternary signal');

      half_length = length/2; 

%generates binary signals
      if level == 1

%checks if pseudo-random signals are available
         if (MLB_exist(half_length)==1) | (QRB_exist(half_length)==1) | (TPB_exist(half_length)==1) | (HAB_exist(half_length)==1)
            count = 0;

%prints on the screen the classes of pseudo-random signals available
            disp ('Pseudo-random binary inverse-repeat signal(s) of this length can be based on the following classes:')
  
            if MLB_exist(half_length) == 1
               disp ('Maximum length binary signal')
               count = count+1;
               MLB_present = 1;
            else
               MLB_present = 0;
            end
            if QRB_exist(half_length) == 1
               disp ('Quadratic residue binary signal')
               count = count +1;
               QRB_present = 1;
            else
               QRB_present = 0;
            end
            if TPB_exist(half_length) == 1
               disp ('Twin Prime signal')
               count = count+1;
               TPB_present = 1;
            else
               TPB_present = 0;
            end
            if HAB_exist(half_length) == 1
               disp ('Hall signal')
               count = count+1;
               HAB_present = 1;
            else
               HAB_present = 0; 
            end     
            fprintf ('\n')
 
%gives user the choice to continue or abort
            to_continue = 'a';
            while (to_continue~='y') & (to_continue~='n')
               to_continue = input('Do you want to generate the signal? y/n [y]:','s');
               if isempty(to_continue)
                  to_continue = 'y';
               end
            end

            if to_continue == 'y'
               if count>1

%allows user the choice of signal class
               repeat_class = 'y';
                  while repeat_class == 'y'
   
                     disp('Choose a signal class by entering the associated character.')
                     if MLB_present == 1
                        disp ('Maximum length binary signal : m')
                     end
                     if QRB_present == 1
                        disp ('Quadratic residue binary signal : b')
                     end
                     if TPB_present == 1
                        disp ('Twin Prime signal : t')
                     end
                     if HAB_present == 1
                        disp ('Hall signal : h')
                     end
   
                     wrong = 1;
                     while wrong == 1

                        class = input('','s');
                        fprintf ('\n')

%generates the pseudo-random signal class chosen
%generates maximum length binary inverse-repeat signal
                        if class == 'm'
                           if MLB_present == 1
                              MLB_series = MLB(length/2);
                              inverse = inverse_repeat(MLB_series);
                              signal_display (inverse)

%calculates upper bound in the crosscorrelation without
%unsystematic errors due to third-order nonlinearities
                              R1 = calculate_R1(MLB_series);
                              fprintf('Upper bound in the crosscorrelation without unsystematic errors due to third-order nonlinearities, R1 is %d.\n\n', R1)

%allows the user to calculate third-order terms
                              answer = 'a';
                              while (answer~='y') & (answer~='n')
                                 answer=input('Do you wish to calculate third-order terms? y/n [y]:','s');
                                 if isempty(answer);
                                    answer = 'y';
                                 end
                              end

                              if answer == 'y'
                                 fprintf('Please enter two integers between 1 and %d or enter [-1 -1] to quit.\n', length-1);
                                 disp('The integers must be increasing in value and entered in the format [integer1 integer2].')
                                 delay1 = 1;
                                 delay2 = 2;

                                 while (delay1~=-1) | (delay2~=-1)
                                    delay = input('Delays = ');
                                    delay1 = delay(1);
                                    delay2 = delay(2);
                                    while ((delay1<1) | (delay1>length-1) | (delay2<1) | (delay2>length-1) | (delay1>delay2)) & ((delay1~=-1) | (delay2~=-1))
                                       fprintf('Please enter two integers between 1 and %d or enter [-1 -1] to quit.\n', length-1);
                                       disp('The integers must be increasing in value and entered in the format [integer1 integer2].')
                                       delay = input('Delays = ');
                                       delay1 = delay(1);
                                       delay2 = delay(2);
                                    end
                                    if (delay1~=-1) & (delay2~=-1)
                                       shift = third_shift(MLB_series,delay1,delay2);
                                       fprintf('The resulting shift is %d.\n\n', shift)
                                    end
                                 end
                              end

                              wrong = 0;
                           else
                              wrong = 1;
                           end
     
%generates quadratic residue binary inverse-repeat signal
                        elseif class == 'b'
                           if QRB_present == 1
                              QRB_series = QRB(half_length);
                              inverse = inverse_repeat(QRB_series);
                              signal_display (inverse)
                              wrong = 0;
                           else
                              wrong = 1;
                           end
 
%generates Twin Prime inverse-repeat signal
                        elseif class == 't'
                           if TPB_present == 1
                              TPB_series = TPB(half_length);
                              inverse = inverse_repeat(TPB_series);
                              signal_display (inverse)
                              wrong = 0;
                           else
                              wrong = 1;
                           end
  
%generates Hall inverse-repeat signal
                        elseif class == 'h'
                           if HAB_present == 1
                              HAB_series = HAB(half_length);
                              inverse = inverse_repeat(HAB_series);
                              signal_display (inverse)
                              wrong = 0; 
                           else
                              wrong = 1;
                           end
   
                        else
                           wrong = 1; 
                        end
  
                        if wrong == 1
                           disp ('Please only enter an available choice.')
                        end
                     end

                     repeat_class = 'a'; 
                     while (repeat_class~='y') & (repeat_class~='n')
                        repeat_class = input('Do you want to generate a pseudo-random inverse-repeat signal based on a different class? y/n [y]:','s');
                        if isempty(repeat_class)
                           repeat_class = 'y';
                        end
                     end
                  end   

               else                       

%generates maximum length binary inverse-repeat signal
                  if MLB_present == 1
                     MLB_series = MLB(length/2);
                     inverse = inverse_repeat(MLB_series); 
                     signal_display (inverse)

%calculates upper bound in the crosscorrelation without
%unsystematic errors due to third-order nonlinearities
                     R1 = calculate_R1(MLB_series);
                     fprintf('Upper bound in the crosscorrelation without unsystematic errors due to third-order nonlinearities, R1 is %d.\n\n', R1)

%allows the user to calculate third-order terms
                     answer = 'a';
                     while (answer~='y') & (answer~='n')
                        answer=input('Do you wish to calculate third-order terms? y/n [y]:','s');
                        if isempty(answer);
                           answer = 'y';
                        end
                     end

                     if answer == 'y'
                        fprintf('Please enter two integers between 1 and %d or enter [-1 -1] to quit.\n', length-1);
                        disp('The integers must be increasing in value and entered in the format [integer1 integer2].')
                        delay1 = 1;
                        delay2 = 2;

                        while (delay1~=-1) | (delay2~=-1)
                           delay = input('Delays = ');
                           delay1 = delay(1);
                           delay2 = delay(2);
                           while ((delay1<1) | (delay1>length-1) | (delay2<1) | (delay2>length-1) | (delay1>delay2)) & ((delay1~=-1) | (delay2~=-1))
                              fprintf('Please enter two integers between 1 and %d or enter [-1 -1] to quit.\n', length-1);
                              disp('The integers must be increasing in value and entered in the format [integer1 integer2].')
                              delay = input('Delays = ');
                              delay1 = delay(1);
                              delay2 = delay(2);
                           end
                           if (delay1~=-1) & (delay2~=-1)
                              shift = third_shift(MLB_series,delay1,delay2);
                              fprintf('The resulting shift is %d.\n\n', shift)
                           end
                        end
                     end

%generates quadratic residue binary inverse-repeat signal
                  elseif QRB_present == 1
                     QRB_series = QRB(half_length);
                     inverse = inverse_repeat(QRB_series);
                     signal_display (inverse)

%generates Twin Prime inverse-repeat signal
                  elseif TPB_present == 1
                     TPB_series = TPB(half_length);
                     inverse = inverse_repeat(TPB_series);
                     signal_display (inverse)

%generates Hall inverse-repeat signal
                  elseif HAB_present == 1
                     HAB_series = HAB(half_length);
                     inverse = inverse_repeat(HAB_series);
                     signal_display (inverse)
                  end
               end                     
            end

%no pseudo-random binary signals available
         else
            disp ('No pseudo-random binary inverse-repeat signal is available for this length.')
            fprintf ('\n')
         end
      end

%generates ternary signals
      if level == 2
         if (QRT_exist(half_length)==1)
            disp ('Pseudo-random ternary inverse-repeat signal(s) of this length can be based on the following classes:')
            disp ('Quadratic residue ternary signal')
            fprintf ('\n')
  
%gives user the choice to continue or abort
            to_continue = 'a';
            while (to_continue~='y') & (to_continue~='n')
               to_continue = input('Do you want to generate the signal? y/n [y]:','s');
               if isempty(to_continue)
                  to_continue = 'y';
               end
            end

%generates quadratic residue ternary inverse-repeat signal
            if to_continue == 'y';     
               QRT_series = QRT(half_length);             
               inverse = inverse_repeat(QRT_series);           
               signal_display (inverse)
            end
        
%no pseudo-random ternary signals available    
         else
            disp ('No pseudo-random ternary inverse-repeat signal is available for this length.')
            fprintf ('\n')
         end
      end

      repeat_level = 'a';
      while (repeat_level~='y') & (repeat_level~='n')
         repeat_level = input('Do you want to generate a signal with a different number of levels? y/n [y]:','s');
         if isempty(repeat_level)
            repeat_level = 'y';
         end
      end
   end
 
   repeat_length = 'a';
   while (repeat_length~='y') & (repeat_length~='n')
      repeat_length = input('Do you want to generate a signal with a different length? y/n [y]:','s');
      if isempty(repeat_length)
         repeat_length = 'y';
      end
   end
end 

