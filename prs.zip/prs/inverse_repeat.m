function inverse = inverse_repeat(bitseries)

%Calculates the inverse-repeat of a given signal.
%
%    inverse = inverse_repeat(bitseries)
%
%    Input argument:
%    bitseries = Vector containing the amplitudes of the signal sequence
%
%    Example:
%    bitseries = [1; 1; -1; 1; -1; -1; 1];
%    inverse = inverse_repeat(bitseries);

%concatenates two periods of a given signal
inverse = [bitseries; bitseries];

%changes the sign of every other element of the signal
for number = 2:2:length(inverse)
   inverse(number) = -(inverse(number));
end


