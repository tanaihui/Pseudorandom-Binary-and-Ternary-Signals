function R0 = calculate_R0(x)

%Calculates the upper bound in the crosscorrelation without
%unsystematic errors due to second-order nonlinearities.
%
%    R0 = calculate_R0(x)
%
%    Input argument:
%    x = Input sequence
%
%    Output argument:
%    R0 = Upper bound in the crosscorrelation without unsystematic
%         errors due to second-order nonlinearities
%
%    Example:
%       x = mlbs(7);
%       R0 = calculate_R0(x)

a=length(x);   
for k = 1:a
   if x(k) == -1
      x(k) = 0;
   end
end

x = [x;x];
store = a;

for m=0:a-1
   if (m >= store)
      break
   end

   for n=m+1:a-1
      if (n >= store)
         break
      end

      for p=n+1:a-1
         if (p >= store)
            break
         end

         if mod(x([a:2*a]-m)+x([a:2*a]-n)+x([a:2*a]-p),2)==0
            if p < store 
               store = p;
            end
         end

      end
   end
end

R0 = store-1;
