%                MATLAB Routine to Generate Perturbation Signals
% 
% This routine incorporates functions to generate binary and ternary 
% pseudo-random signals with length N up to 50000. Five classes of signals 
% are available :- 
% 
% Maximum length binary (MLB) signals 
% Quadratic residue binary (QRB) signals 
% Quadratic residue ternary (QRT) signals 
% Hall binary (HAB) signals 
% Twin Prime binary (TPB) signals
%
% Functions are also available to calculate three measures of signal quality :- 
%
% Performance Index for Perturbation Signals (PIPS) 
% Effective Performance Index for Perturbation Signals (PIPSE) 
% Effective minimum ratio between the actual harmonic amplitude and the specified 
% harmonic amplitude at any of the specified harmonics (EMINE).
%
% If, in addition, the user has the Frequency Domain System Identification Toolbox,
% then the user can generate MLB signals without having to know their characteristic
% polynomials, since the Toolbox is used to provide a default signal for any value 
% of N. (The generation of QRB, QRT, HAB and TPB signals is not affected by the 
% availability of the Toolbox.) 



