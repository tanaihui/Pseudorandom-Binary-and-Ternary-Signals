function exist = QRB_exist(length)

%Checks if the quadratic residue binary sequence exists for a particular length.
%
%    QRB_exist(length)
%
%    Input argument:
%    length = Length of the signal
%
%    Output argument:
%    exist = 1 means that the quadratic residue binary sequence exists.
%          = 0 means that the quadratic residue binary sequence does not exist.
%
%    Example:
%       exist = QRB_exist(46);

if (prime(length)==1) & (mod(length+1,4)==0)
   exist=1;
else
   exist=0;
end
