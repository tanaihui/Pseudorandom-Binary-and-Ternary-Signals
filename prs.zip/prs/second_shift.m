function shift = second_shift(bitseries,delay)

%Calculates the delay when a binary sequence is multiplied by the same sequence 
%shifted by a certain delay.
%
%    shift = second_shift(bitseries,delay)
%
%    Input arguments:
%    bitseries = Vector containing the amplitudes of the signal sequence
%    delay = Delay in the second sequence with respect to the first
%
%    Example:
%       x=mlbs(7);
%       second_shift(x,1)
     
N=length(bitseries);

%calculates the delayed sequence
ud(1:delay)=bitseries(N-delay+1:N);
ud(delay+1:N)=bitseries(1:N-delay);
ud=ud';

%calculates the resulting shift
R=real(ifft(conj(fft(bitseries)).*fft(bitseries.*ud)))/N;
[i,j]=find(R<0);
shift=i-1;