function EMINE_new = calculate_EMINE_new(bitseries,freqv,ampv,option)

%Calculates the minimum ratio of the actual harmonic amplitude and the
%specified harmonic amplitude.
%
%    EMINE_new = calculate_EMINE_new(bitseries,freqv,ampv,option)
%
%    Input arguments:
%    bitseries = Vector containing the amplitudes of the signal
%    freqv = Vector of the specified non-zero frequencies
%    ampv = Amplitude vector at the specified non-zero frequencies
%    option = Choice of whether the effect of ZOH is taken into account
%             0: Effect of ZOH is not taken into account
%             1: Effect of ZOH is taken into account
%             default = 1
%        
%    Output argument:
%    EMINE_new = Minimum ratio of the actual to the specified harmonic amplitude
%
%    Algorithm for ZOH compensated:
%    |C'u(k)| = sqrt(2)*|sin(pi*k/N)/(pi*k)*U(k) 
%    where
%       |C'u(k)| = actual harmonic amplitude at harmonic number k
%       U(k) = discrete Fourier transform of the discrete signal
%       N = signal length
%                                                  
%    EMINE = 100*minimum(|C'u(k)|/|Cs'u(k)|)*sqrt(sum(|Cs'u(k)|^2)/sum(|C'u(k)|^2))% 
%              specified k                     specified k      specified k
%    where
%       |Cs'u(k)| = specified harmonic amplitude at harmonic number k
%
%    Algorithm for ZOH uncompensated:
%    As above with C'u(k) replaced by U(k) for both actual and specified amplitudes
%
%    Example:
%    bitseries = [1 -1 1 -1 -1 1 -1 1 -1 1 1 -1 -1 1 1 1 1 -1 -1 -1];
%    freqv = 1:9;
%    ampv = [9:-1:1]';
%    option = 1;
%    EMINE_new = calculate_EMINE_new(bitseries,freqv,ampv,option)
         
%calculates actual harmonic amplitudes
DFT = abs(fft(bitseries));
for k = 1:length(freqv)
   if option == 1
      angle(k) = pi*(freqv(k))/length(bitseries);
      amp(k) = sqrt(2)*abs(sin(angle(k)).*DFT(freqv(k)+1))/angle(k)/length(bitseries);
   else
      amp(k) = DFT(freqv(k)+1);
   end
end
   
%calculates specified harmonic amplitudes
amps = ampv';

%calculates the minimum ratio of the actual to the specified harmonic amplitude
EMINE_new = 100*min(amp./amps)*sqrt(sum(amps.^2)/sum(amp.^2));
